//$("<span id = 'ombaqExtensionBody'></span>").appendTo(document.body);

// inject js to web pages



// function injectJs(srcFile) {
//     var scr = document.createElement('script');
//     scr.src = srcFile;
//     document.getElementsByTagName('body')[0].appendChild(scr);    
// }
// injectJs(chrome.extension.getURL('js/jquery.js'));

// injectJs(chrome.extension.getURL('js/yourscript.js'));

// function alerts(){
// 	alert('ini inject content_script');
// }
// console.log(window.location.href);

// window.addEventListener("message", function (event) {    
//     console.log(event);
// }, false);

// alert('zz');